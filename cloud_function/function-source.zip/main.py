# function.py
def hello_world(request):
    return 'Hello, World!', 200
